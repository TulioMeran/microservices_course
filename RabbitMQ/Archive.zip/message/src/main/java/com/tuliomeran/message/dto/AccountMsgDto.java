package com.tuliomeran.message.dto;

public record AccountMsgDto (Long accountNumber, String name, String email, String mobileNumber) {
}
